https://www.youtube.com/watch?v=Lw2rlcxScZY&list=PL-osiE80TeTsWmV9i9c58mdDCSskIFdDS&index=4

https://www.youtube.com/watch?v=KdmPHEnPJPs&list=PL-osiE80TeTsWmV9i9c58mdDCSskIFdDS&index=9

https://www.youtube.com/watch?v=UFuo7EHI8zc&list=PL-osiE80TeTsWmV9i9c58mdDCSskIFdDS&index=10

https://pandas.pydata.org/docs/user_guide/10min.html

https://www.geeksforgeeks.org/sort-a-pandas-series-in-python/

https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.to_datetime.html



the output

Hello! Let's explore some US bikeshare data!
you must choose one of those [chicago, new_york_city, washington]

Calculating The Most Frequent Times of Travel...

the most common month is June
the most common day is Monday
the most common hour is 17

This took 0.11561822891235352 seconds.
----------------------------------------

Calculating The Most Popular Stations and Trip...

common_start is  Pershing Square North
common_end is Pershing Square North
common_comination is ('E 7 St & Avenue A', 'Cooper Square & E 7 St')

This took 0.01994609832763672 seconds.
----------------------------------------

Calculating Trip Duration...

total travel time 35132088
mean travel time 838.0146458984328

This took 0.0009970664978027344 seconds.
----------------------------------------

Calculating User Stats...

the count of each user is 
 Subscriber    38696
Customer       3132
Name: User Type, dtype: int64
the count of each gender is 
 Gender
Female     9122
Male      29617
dtype: int64
earliest year of birth	1885
 most recent year of birth	2001
and most common year of birth	1985

This took 0.00601649284362793 seconds.
----------------------------------------
